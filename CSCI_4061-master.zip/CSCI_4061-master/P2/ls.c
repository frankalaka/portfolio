#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>
#include <dirent.h>


void ls(char *path, bool recurse_flag) {
    /* Insert code here*/
    if (!path){
        path = ".";
    }
    char* pathHolder = malloc(256*sizeof(char));
    strcpy(pathHolder, path);
    if (recurse_flag == true){
        printf("%s: \n", pathHolder);
    }
    DIR *dir = opendir(pathHolder);
    if (dir == NULL){
        printf("Could not open directory: %s\n", pathHolder);
        exit(1);
    }
    struct dirent *content = readdir(dir);
    int dir_size;
		int rowcount = 0;
		char d_name[240];
		char slash = '/';
    while (content!=NULL){
        if(strcmp(content->d_name,".") && strcmp(content->d_name,"..")){
					strcpy(d_name, content->d_name);
					if (content->d_type == DT_DIR){
						size_t len = strlen(d_name);
						d_name[len] = slash;
    				d_name[len + 1] = '\0';
					}
          printf("%-15s", d_name);
					rowcount++;
					if (rowcount >= 4){
						printf("\n");
						rowcount=0;
					}
        }
        content = readdir(dir);
    }
    if (recurse_flag){
    rewinddir(dir);
        content = readdir(dir);
    while (content !=NULL){
            if(strcmp(content->d_name,".") && strcmp(content->d_name,"..")){
                if (content->d_type == DT_DIR){
                    printf("\n\n");

                    //new = newPath(path,content->d_name); // BUG: Cannot create new path string without mutating original path
                    ls(strcat(strcat(pathHolder,"/"),content->d_name), true);
                    strcpy(pathHolder,path);
                }
            }
            content = readdir(dir);
        }
    }
}

int main(int argc, char *argv[]){
	if(argc < 2){ // No -R flag and no path name
	        ls(NULL, false);
	} else if(strcmp(argv[1], "-R") == 0) {
	        if(argc == 2) { // only -R flag
	                ls(NULL, true);
	        } else { // -R flag with some path name
	                ls(argv[2], true);
	        }
	}else { // no -R flag but path name is given
	ls(argv[1], false);
	}
	return 0;
}

//------------------------------------------------------------------------------------------------------//
//
// int redirect(int type, char* program, char* file){
//   int fd;
//   if (type == 0) {  // Append
//       fd = open(file, O_APPEND | O_WRONLY);
//   } else if (type == 1) ( // Truncate
//       fd = open(file, O_TRUNC | O_WRONLY);
//   if(dup2(fd,1) < 0) {
//       close(file);
//       exit(0);
//   }
// }
