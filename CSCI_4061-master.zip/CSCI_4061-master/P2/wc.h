


/*Flag bit definitions*/

#define PRINT_LINE					0x1
#define PRINT_WORD					0x2
#define PRINT_CHARACTER				0x4
	

/*Flags to determine which argument the newline should follow in the output*/
#define WC_LINE						0x1
#define WC_WORD						0x2
#define WC_CHARACTER				0x4	
