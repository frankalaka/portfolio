#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <errno.h>
#include <sys/wait.h>
#include <stdbool.h>
#include <fcntl.h>

#include "util.h"

int INPUT_LENGTH = 240;

void executeCommand(char *cmds){
	// Token for reading input
	char *token;
	char *command;
	char *args[11];
	int num_command = 0;
	char space[2] = " ";
	token = strtok(cmds, space);
	// Get arguments, ignore piping and redirection tokens
	while (token!= NULL && strcmp(token,">>") != 0 && strcmp(token,">") != 0 && strcmp(token,"|") != 0){
		args[num_command] = token;
		token = strtok(NULL, space);
		num_command+=1;
	}
	// Execute commands
	args[num_command] = NULL;
	execvp(args[0], args);
}

void getInput(char* input){
	// Get user input, save to pointer
  char cwd[100];
  if (getcwd(cwd, sizeof(cwd))) {
      printf("[4061-shell]%s $ ", cwd);
      fgets(input, INPUT_LENGTH, stdin);
      input[strcspn(input, "\n")] = 0;
  } else {
      perror("Error getting current directory");
      exit(1);
  }
}

int main(){
	// Variables
  char * input = malloc(sizeof(char)*INPUT_LENGTH);
  char * cpyinput = malloc(sizeof(char)*INPUT_LENGTH);
  char *input_token;
	char initial_directory[INPUT_LENGTH];
  char space[2] = " ";
  int flag = 0;
  int hold;
  int fd;
  pid_t p1;

	getcwd(initial_directory,sizeof(initial_directory));

  while (strcmp(input, "exit") != 0){
    // Prompt for input
    getInput(input);
    strcpy(cpyinput,input);
    if (!*input){
      continue;
    }
    // checking if the >> exists
    if (strstr(input," >> ") != NULL){
      flag = 1;
    } else if (strstr(input, " > ") != NULL){
      flag = 2;
    }
    if (flag != 0){
      input_token = strtok(input,space);
      while (input_token != NULL){
        input_token = strtok(NULL,space);
				// check for redirection!
        if (strcmp(input_token,">>") == 0 || strcmp(input_token,">") == 0)  {
          input_token = strtok(NULL,space);
          hold = dup(1);  // get the STDLINE
          if (flag == 1){  // >> or >
            fd = open(input_token,O_CREAT | O_APPEND | O_WRONLY);
          } else if (flag == 2) {
            fd = open(input_token,O_CREAT | O_TRUNC | O_WRONLY);
          }
          dup2(fd,1);  //  Change the default out into the opened file
          close(fd);
          input_token = NULL;
        }
      }
    }

    // Evaluate command
    input_token = strtok(cpyinput,space);
    if (strcmp(input_token, "cd") == 0){
      // cd doesn't work with fork, need to chdir
      input_token = strtok(NULL, space);
			if (strcmp(input_token, "~")==0){
				input_token = getenv("HOME");
			}
      chdir(input_token);
    } else if (strcmp(input_token, "ls")== 0){
      // Calling ls
      input_token = strtok(NULL, space);
      if (input_token != NULL && strcmp(input_token, "-R")== 0){  // check for -R
        input_token = strtok(NULL, space);
        if (input_token == NULL || strcmp(input_token,">") == 0 || strcmp(input_token, ">>") == 0){
          input_token = NULL;
        }
        p1 = fork();  // fork and execute
        if (p1 < 0) {
          printf("ls fork failure!");
          exit(0);
        } else if (p1 == 0) {
					// Use the initial directory to combat directory changes
          char modified_command[100];
          strcpy(modified_command, initial_directory);
          strcat(modified_command, "/ls");
          execl(modified_command,"ls","-R",input_token,NULL);  // exec the ls -R command
        } else {
          wait(NULL);
        }
      } else {
        if (input_token == NULL || strcmp(input_token,">") == 0 || strcmp(input_token, ">>") == 0){
          input_token = NULL;
        }
        p1 = fork();
        if (p1 < 0) {
          printf("ls fork failure!");
          exit(0);
        } else if (p1 == 0) {
					// Use the initial directory to combat directory changes
          char modified_command[100];
          strcpy(modified_command, initial_directory);
          strcat(modified_command, "/ls");
          execl(modified_command,"ls",input_token,NULL);
        } else {
          wait(NULL);
        }
      }
      printf("\n");
      input_token = strtok(NULL, space);

    } else if (strcmp(input_token, "wc")== 0){
      p1 = fork();
      if (p1 < 0) {
        printf("wc fork failure!");
        exit(0);
      } else if (p1 == 0) {
				// Use the initial directory to combat directory changes
				char modified_command[100];
				strcpy(modified_command, initial_directory);
				strcat(modified_command, "/wc");
        execl(modified_command,"wc",input_token,NULL);
      } else {
        wait(NULL);
      }
    } else if (strcmp(input_token, "exit")== 0){
      break;
    }
		else {
			// Execute using exec for any calls
	   p1 = fork();
	   if (p1 < 0) {
				printf("system call fork failure!");
				exit(0);
	   } else if (p1 == 0) {
	     executeCommand(input);
	   } else {
	      wait(NULL);
	   }
    }
    if (flag != 0){
      dup2(hold,1);
      flag = 0;
    }
  }
  printf("shell terminated\n");
  free(input);
  return 0;
}
