#include "wc.h"
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>





int main(int argc, char* argv[]){
	
	/*check the number of arguments*/
	if(argc <= 1){
		fprintf(stderr, "Insufficient number of arguments. A minimum of 1 is expected, and %d were given.\n", argc - 1);
		exit(-1);
	}
	
	/*parse the command line arguments*/
	
	uint8_t arg_flag = 0x0;
	uint8_t i = 2;
	uint8_t newline_arg = 0;
	
	for(; i <= argc - 1; i++){ //argv[0] is the name of the program, and argv[1] is the filename, so i starts at 2.
		
		if(strcmp(argv[i], "-l") == 0){
			arg_flag |= PRINT_LINE;
			
			/*This uses a dominance scheme to determine whether the output's newline should occur after line, word, or character*/
			
			/*Line is superceded by word and character*/
			if(newline_arg != WC_WORD && newline_arg != WC_CHARACTER){
				newline_arg = WC_LINE;
			}
			
		}
		
		else if(strcmp(argv[i], "-w") == 0){
			arg_flag |= PRINT_WORD;
			
			/*Word is superceded by character*/
			if(newline_arg != WC_CHARACTER){
				newline_arg = WC_WORD;
			}
		}
		
		else if(strcmp(argv[i], "-c") == 0){
			arg_flag |= PRINT_CHARACTER;
			
			/*Character supercedes word and character options*/
			newline_arg = WC_CHARACTER;
		}
	}
	
	/*open the file*/
	
	int file_fd = -1;
	
	while(file_fd == -1){
		file_fd = open(argv[1], O_RDONLY);
		
		if(file_fd == -1){
			
			/*Check the errno*/
			
			if(errno == EACCES){
				fputs("Permission denied, or the file does not exist\n", stderr);
				exit(-1);
			}
			
			else if(errno == EISDIR){
				fprintf(stderr, "%s is a directory\n", argv[1]);
				exit(-1);
			}
			
			
			else fprintf(stderr, "File open error\n");
			exit(-1);
		}
	
		
	}

	
	/*parse the file for word count*/
	
	lseek(file_fd, 0, SEEK_SET);
	
	char read_char = 0;
	uint32_t bytes_r = 0;
	
	/*variables to store word, line, and character count*/
	uint32_t words = 0;
	uint32_t lines = 0;
	uint32_t characters = 0;
	
	/*get the size of the file*/
	off_t fsize = lseek(file_fd, 0, SEEK_END);
	
	/*move the offset back to the start of the file*/
	lseek(file_fd, 0, SEEK_SET);
	
	/*read words in the file*/
		
	for(off_t i = 0; i < fsize; i++){
		
		read(file_fd, &read_char, 1);
		
		/*words are separated by either newlines or spaces*/
		if(read_char == ' ' || read_char == '\n'){
			words++;
		}
		
		/*lines are indicated by newlines*/
		if(read_char == '\n'){
			lines++;
		}
		
		characters++;
	}
	
	
	/*check the argument flags to know how to output.*/
	if(arg_flag & PRINT_LINE){
		
		if(newline_arg & WC_LINE){
			printf("%d\n", lines);
		}
		
		else printf("%d ", lines);
	}
	
	if(arg_flag & PRINT_WORD){
		
		if(newline_arg & WC_WORD){
			printf("%d\n", words);
		}
		
		else printf("%d ", words);
	}
	
	if(arg_flag & PRINT_CHARACTER){
		
		if(newline_arg & WC_CHARACTER){
			printf("%d\n", characters);
		}
		
		else printf("%d ", characters);
	}
	
	if(argc == 2){ //This is the no option parameters case.
		printf("%d %d %d\n", lines, words, characters);
	}
	
	while(close(file_fd) == -1);
	
	exit(0);
}
