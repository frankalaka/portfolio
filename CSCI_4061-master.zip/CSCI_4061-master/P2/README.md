[comment]: <> (
  test machine: csel-apollo
  date: 03/05/21
  name: Kiet Ho, Austin Glynn, Frank Back
  x500: hoxxx433, glynn047, backx039
  )

# Purpose
A program that implements a shell command that takes in user inputs and run our own version of cd, ls and wc. The shell also supports, piping and redirection. Any other commands are called using the system call commands

# What it does
The program takes in a user input, parses the inputs and arguments. From there, if the input is a valid command, the shell runs the following commands:
* ls
* cd
* cw

Other commands will use system calls.

## How to Compile
Download repository, use make command to build in command line.

Compiling:
```bash
make
```

Cleanup:
```bash
make clean
```

## Usage
To run in command line:
```bash
./shell
```

## Contributions
Program was done individually to be compiled as a team. Contribution are split up as follows:
* Kiet Ho: Implementing cd and exit + Command parsing and execution logic
* Frank Back: Implementing ls + file redirection
* Austin Glynn: Implementing wc + pipes

## Known bugs
None that we know of

## Test cases
ls:
```bash
ls
ls -R
ls -R ../..
ls >> out.txt
ls -R >> out.txt
```
cd:
```bash
cd
cd ..
cd /PATH
cd ~
```

cw:
```bash
cw README.md
```

redirection:
```bash
ls > out.txt
ls -R > out.txt
cat >> out.txt
cat README.md > out.txt
```

piping:
```bash
cat README.md | grep piping
ls | wc > out.txt
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
