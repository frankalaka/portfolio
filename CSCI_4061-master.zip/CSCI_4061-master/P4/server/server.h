#ifndef SERVER_H
#define SERVER_H
#define MSGSZ 512
#endif
