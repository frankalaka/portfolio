#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <dirent.h>
#include <stdio.h>
#include "server.h"
#include <ctype.h>

// Global vars
pthread_mutex_t mutex;
pthread_mutex_t mutex2;
pthread_cond_t cond = PTHREAD_COND_INITIALIZER;

int alphacount[26];
int done_count = 0;
int num_clients;

typedef struct{
    long msg_type;
    char msg_text[MSGSZ];
} msg_buffer;

typedef struct s_thread_args{
  int msgid;
  int threadid;
} thread_args;

// Server sending rule: Receiving TID, sending TID+1000
void *readFileCount(void* args) {
    // Set up messaging
    thread_args* thread_arg = (thread_args *) args;
    msg_buffer msg;
    // Create ID
    int tid =  thread_arg->threadid;
    // printf("TID: %ld\n",tid);
    int msgid = thread_arg->msgid;

    // Vars for reading dirs
    char chunk[MSGSZ];
    char final[MSGSZ] = "";
    char buf[MSGSZ];
    size_t len = sizeof(chunk);

    // Get message with TID
    // printf("Waiting for file...\n");
    msgrcv(msgid, (void*)&msg, MSGSZ, tid, 0);

    // Receive stuff
    while(strcmp(msg.msg_text, "END") != 0) {
        printf("%d filepath received: %s\n", tid,msg.msg_text);
        // Access file and count
        FILE * fp = fopen(msg.msg_text, "r");
        if(fp == NULL){
          printf("Could not open dir: %s\n", msg.msg_text);
          msgctl(msgid, IPC_RMID, NULL);
          exit(-1);
        }

        // TODO: USE getline fgets is not thread safe
        char * line = NULL;
        size_t l = 5000;
        ssize_t r;
        while((r = getline(&line, &l, fp)) != -1) {
            pthread_mutex_lock (&mutex);
            // printf("%d %s %d\n", (int) tolower(line[0])-97, line, strlen(line));
            // fflush(stdout);
            alphacount[(int) tolower(line[0])-97]++;

            pthread_mutex_unlock(&mutex);
        }
        fclose(fp);
        // Send ACK
        // Change msg and send type
        printf("%d sending acknowledgement for path: %s\n", tid,msg. msg_text);
        strcpy(msg.msg_text, "ACK");
        msg.msg_type = tid+1000;
        // Send ACK with TID+1000
        msgsnd(msgid, (void*)&msg, MSGSZ, 0);
        // Receive next message with TID
        msgrcv(msgid, (void*)&msg, MSGSZ, tid, 0);
    }
    printf("%d end received\n", tid);

    // Check if other threads are ended, if not wait.
    pthread_mutex_lock(&mutex2);
    done_count +=1;
    pthread_mutex_unlock(&mutex2);
    // If all thread not finished, wait
    while (done_count < num_clients);
    // 
    // while(1){
    //   printf("Enter wait\n");
    //   pthread_mutex_lock(&mutex2);
    //   if (done_count == num_clients){
    //     printf("Increment count\n");
    //     done_count+=1;
    //     pthread_cond_signal(&cond);
    //   } else {
    //     while (done_count < num_clients){
    //       printf("Waiting\n");
    //       pthread_cond_wait(&cond, &mutex2);
    //       if (done_count == num_clients){
    //         break;
    //       }
    //     }
    //   }
    //
    // }


    // All threads are finished

    // Send final count
    snprintf(final, sizeof(final), "%d", alphacount[0]);
    for(int i = 1; i < 26; i++){
        snprintf(buf, sizeof(buf), "#%d", alphacount[i]);
        strcat(final,buf);
    }
    printf("%d sending global count\n", tid);
    strcpy(msg.msg_text, final);
    msg.msg_type = tid+1000;
    msgsnd(msgid, (void*)&msg, MSGSZ, 0);
    pthread_exit(NULL);

}

int main(int argc, char const *argv[]) {
    if (argc < 2) {
        printf("Arguments missing! (number_of_clients)\n");
        exit(1);
    }
    printf("Server starting\n");

    num_clients = atoi(argv[1]);
    pthread_t threads[num_clients];

    // Create msg queue
    // Call once, delete and call again
    key_t key = ftok("../progfile",99);
    int msgid = msgget(key, 0666 | IPC_CREAT);
    // Empty buffer just in case
    msgctl(msgid, IPC_RMID, NULL);
    msgid = msgget(key, 0666 | IPC_CREAT);

    thread_args thread_args[num_clients];

    for(int i = 0; i < num_clients; i++){
      thread_args[i].msgid = msgid;
      thread_args[i].threadid = i+1;
      if (pthread_create(&threads[i], NULL, readFileCount, (void *) &thread_args[i])){
        printf("Error creating threads\n");
        return -1;
      }
    }

    for(int i = 0; i < num_clients; i++){
      pthread_join(threads[i], NULL);
    }
    printf("Ending server\n");
    return 0;
}
