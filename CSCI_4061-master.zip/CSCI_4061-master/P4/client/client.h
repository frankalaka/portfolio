#ifndef CLIENT_H
#define CLIENT_H

#define MSGSZ 512

#endif
