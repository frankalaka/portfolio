#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <dirent.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "client.h"

char paths[500][99];

typedef struct{
    long msg_type;
    char msg_text[MSGSZ];
} msg_buffer;

void traverseDir(const char *name, int *pct){
    DIR *dir;
    struct dirent *entry;
    if (!(dir = opendir(name)))
        return;
    while ((entry = readdir(dir)) != NULL) {
        if (entry->d_type == DT_DIR) {
            char path[1024];
            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0){
                continue;
            }
            snprintf(path, sizeof(path), "%s/%s", name, entry->d_name);
            traverseDir(path, pct);
        } else {
            strcat(paths[*pct], name);
            strcat(paths[*pct], "/");
            strcat(paths[*pct], entry->d_name);
            // printf("%d %s\n", *pct,paths[*pct]);
            *pct = *pct+1;
        }
    }
    closedir(dir);
}

void write_input(int num_clients, int split, char* folder){
    for (int i = 0; i < num_clients; i++){
        char file_path[48];
        snprintf(file_path, sizeof(file_path), "%s/Client%d.txt", folder, i);
        FILE * fp = fopen(file_path, "w+");
        // Create and write file for each client
        for (int j = 0; j <split; j++){
            int index = i+(j*num_clients);
            // printf("%d\n", index);
            // printf("%s\n", paths[index]);
            // Write each entry into file
            fputs(paths[index], fp);
            fputs("\n", fp);
        }
        fclose(fp);
    }
}

// Client sending rule: Receiving TID+1000, sending TID. change message and tpye before send and receive
void message_file(int tid, char* folder1,char* folder2, int msgid){

    // Create TID
    // printf("TID: %ld\n",tid);
    msg_buffer msg;

    // Set up reading dirs
    char chunk[MSGSZ];
    size_t len = sizeof(chunk);
    char file_path[48];
    snprintf(file_path, sizeof(file_path), "%s/Client%d.txt", folder1, tid-1);

    // Open and read files
    FILE * fp = fopen(file_path, "r");
    if (fp == NULL){
      printf("Error opening file\n");
      msgctl(msgid, IPC_RMID, NULL);
      return;
    }

    while(fgets(chunk, len, fp) != NULL) {
        chunk[strlen(chunk)-1] = '\0';
        // Send filepath with TID
        msg.msg_type = tid;
        strcpy(msg.msg_text,chunk);
        msgsnd(msgid, (void*)&msg, MSGSZ, 0);
        printf("%d sending: %s\n", tid, msg.msg_text);
        // Receive message with TID+1000
        msgrcv(msgid, (void*)&msg, MSGSZ, tid+1000, 0);
        if(strcmp(msg.msg_text, "ACK") == 0){
             printf("%d acknoledgedment received\n", tid);
        } else  {
          printf("Unexpected message received %s\n", msg.msg_text);
        }
    }
    // Close read file
    fclose(fp);

    // Send end message
    msg.msg_type = tid;
    strcpy(msg.msg_text, "END");
    msgsnd(msgid, (void*)&msg, MSGSZ, 0);
    printf("%d sending end\n", tid);

    // Receive final count
    msgrcv(msgid, (void*)&msg, MSGSZ, tid+1000, 0);
    printf("%d final count received: %s\n", tid, msg.msg_text);

    // Store final count
    snprintf(file_path, sizeof(file_path), "%s/Client%d_out.txt", folder2, tid-1);
    FILE * fp2 = fopen(file_path, "w+");
    if (fp2 == NULL){
      printf("Could not open client input file\n");
      return;
    }
    fputs(msg.msg_text,fp2);
    fclose(fp2);

    // Clear message buffer, probably needs to be done at the end
    msgctl(msgid, IPC_RMID, NULL);
}
// TODO: 1 msgid
int main(int argc, char** argv) {
    if (argc < 3) {
        printf("Arguments missing! (path_to_folder, number_of_clients)");
        exit(1);
    }
    printf("Client started\n");
    // Set up messaging
    key_t key = ftok("../progfile",99);
    int msgid = msgget(key, IPC_CREAT | 0666);
    // Remove
    int num_clients = atoi(argv[2]);  // number of clients

    char * path = argv[1];  // absolute path to a folder
    char folder1[24] = "ClientInput";
    mkdir(folder1, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    char folder2[24] = "Output";
    mkdir(folder2, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    int count = 0;
    int * pct = &count;
    printf("Traversing folder\n");
    traverseDir(path,pct);
    int client_split = (float) count/(float) num_clients;
    // printf("Entry count: %d\n", *pct);
    printf("Partitioning %d clients\n", num_clients);

    write_input(num_clients, client_split, folder1);
    for(int i = 0; i < num_clients; i++){ // forking
        pid_t pid1 = fork();
        if(pid1 == 0){
            message_file(i+1,folder1,folder2, msgid);
            exit(0);
        }
    }
    // Empty buffer at the end here
    for(int j = 0; j < num_clients; j++){
        wait(NULL);
    }
    printf("Ending client\n");
}
