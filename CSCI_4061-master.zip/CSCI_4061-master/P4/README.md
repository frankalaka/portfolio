<!--
test machine: csel-apollo
date: 04/30/20
name: Kiet Ho, Austin Glynn, Frank Back
x500: hoxxx433, glynn047, backx039
-->


# Description

This project uses a client and a server program which communicate via message queues to process many separate sets of files from separate clients.

# What It Does

The client program evenly divides text files between client processes, and each sends them to the server program.

The server program counts the number of words beginning with each letter in each client process and returns the result to each client process via a message queue.

# How to Compile

## Compiling
```bash
make
```

## Cleaning
```bash
make clean
```

## Executing
The server program must be started before the client program.

### Executing Server Program
Provide the number of clients to handle.
```bash
./server/server 2
```

### Executing Client Program
Provide the file path for the input directory and number of clients
```bash
./client/client /TestCases/TestCase2/ 2
```

# Assumptions

- ‘server’ program will run before the ‘client’ program.
2. Both server and client will be executed on the same machine.
3. The files in the input directory of the client will have a single word per line not exceeding 50 characters and the number of words per file can vary.
4. The number of files present in the input directory to client should exceed the number of client processes unless it is an empty folder.
5. The argument for server program and the second argument for client program will be the same (number of client processes).


# Team Contributions

Kiet Ho: Server program

Frank Back: Client program

Austin Glynn: Write README
