/*
test machine: csel-apollo
date: 02/19/21
name: Kiet Ho, Austin Glynn, Frank Back
x500: hoxxx433, glynn047, backx039
*/

#include "main.h"
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void executeCommand(char cmds[550]){
	// printf("Executing command: %s\n", cmds);
	char *token;
	char *command;
	char *args[11];
	int num_command = 0;
	char space[2] = " ";
	token = strtok(cmds, space);
	// Get arguments
	while (token!= NULL){
		args[num_command] = token;
		token = strtok(NULL, space);
		num_command+=1;
	}
	args[num_command] = NULL;
	execvp(args[0], args);
}

void append_result(char* cmds){
	FILE *out = fopen("results.txt", "ab");
	if(out == NULL) {
		perror("Failed to open the output file");
		exit(1);
	}
	fprintf(out, "%d %d %s\n", getpid(), getppid(), cmds);
	if(fclose(out) == EOF) {
		perror("Failed to close the output file");
		exit(1);
	}
}

void traverseGraph(struct DepGraph *graph, int current, char cmds[32][550]){
	struct AdjListNode *node = graph->array[current].head;
	while (node->next != NULL){
		int dest = node->dest;
		int pid = fork();
		if (pid == 0) {
			traverseGraph(graph, dest, cmds);
			return;
		} else {
			wait(NULL);
			node = node->next;
		}
	}
	// printf("%d %d %s\n", getpid(), getppid(), cmds[current]);

	append_result(cmds[current]);

	executeCommand(cmds[current]);
	// system(cmds[current]); // Does things differently but works
}

// Print graph for testing
void printGraph(struct DepGraph *graph){
	printf("---Printing Graph Structure---\n");
	for (int i = 0; i<graph->V; i++){
		struct AdjListNode node = *graph->array[i].head;
		printf("origin: %d\n", i);
		while(node.next != NULL){
			printf("	dest: %d\n", node.dest);
			node = *node.next;
		}
	}
}

void free_graph(struct DepGraph *graph){
	for (int i = 0; i<graph->V; i++){
		struct AdjListNode *node = graph->array[i].head;
		while(node->next != NULL){
			struct AdjListNode *temp_node = node;
			node = node->next;
			free(temp_node);
		}
		free(node);
	}
	// free(graph->array);
	free(graph);
}

int main(int argc, char **argv) {
	// Check number of arguments
	if (argc != 2) {
		printf("Incorrect number of arguments...\n");
		printf("Usage: ./proctree input_text_file\n");
		return -1;
	}
	// Variables
	char *file = argv[1];
	struct stat fstat;
	stat(file, &fstat);
	int fsize = fstat.st_size;
	char cmds[32][550];

	// Open the input file
	FILE *in = fopen(file, "r");
	if(in==NULL) {
		perror("Failed to open the input file");
		return-1;
	}
	char *buffer = malloc(fsize);

	// Get number of nodes
 	int num_node;
	char *num_buffer = fgets(buffer, fsize, in);
	int success = sscanf(num_buffer, "%d", &num_node);
	if (!success){
		printf("Could not parse input number of nodes");
		return -1;
	}
	fgets(buffer, fsize, in);	// Skip blank line

	// Get graph data
	struct AdjList adj_array[num_node];
	for (int i = 0; i<num_node; i++){
		fgets(cmds[i], fsize, in);
		struct AdjListNode *node = (struct AdjListNode*) malloc(sizeof(struct AdjListNode));
		node-> dest = -1;
		node->next = NULL;
		adj_array[i].head = node;
	}
	fgets(buffer, fsize, in); 	// Skip blank line

	// Get relationship data
	int dest_list[num_node][2];
	int dest_count = 0;
	int origin, dest;

	while(fgets(buffer, fsize, in)) {
		int success = sscanf(buffer, "%d %d", &origin, &dest);
		if(!success){
			printf("Could not get input relationship");
			return -1;
		}
		// Create and add new node
		struct AdjListNode *curr_node = adj_array[origin].head;
		while(curr_node->next != NULL	){
			curr_node = curr_node->next;
		}
		// Assign relationship
		curr_node->dest = dest;
		struct AdjListNode *new_node = (struct AdjListNode*) malloc(sizeof(struct AdjListNode));
		curr_node->next = new_node;
		new_node->dest = -1;
		new_node->next = NULL;
		dest_count++;
	}
	// Close input file
	if (fclose(in) == EOF){
		printf("Failed to close the input file\n");
		return -1;
	}

	// Make graph
	struct DepGraph *graph = malloc(sizeof(struct DepGraph));
	graph->V = num_node;
	graph->array = adj_array;

	// Print for testing
	// printGraph(graph);

	// Traverse graph and execute commands
	traverseGraph(graph, 0, cmds);

	// Free everything
	free_graph(graph);
	free(buffer);

	return 0;
}
