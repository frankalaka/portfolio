#ifndef MAIN_H
#define MAIN_H

#include "graph.h"
#endif