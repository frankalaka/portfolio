[comment]: <> (
  test machine: csel-apollo
  date: 02/19/21
  name: Kiet Ho, Austin Glynn, Frank Back
  x500: hoxxx433, glynn047, backx039
  )

# Purpose
A program to read input commands and create threads to execute those commands in a depth-first fashion

# What it does
The program takes in an input file, present in the Test Cases folder, reads each input and builds a dependency graph to structure how to execute the commands. The graph is then traversed to be executed depth-first. The output of the commands are printed into an output file results.txt.  

## How to Compile
Download repository, use make command to build in command line.

Compiling:
```bash
make
```

Cleanup:
```bash
make clean
```

## Usage
To run in command line:
```bash
./depGraph [input_file.txt]
```

## Contributions
Program was done individually to be compiled as a team. Source code submitted by Kiet Ho.


## License
[MIT](https://choosealicense.com/licenses/mit/)
