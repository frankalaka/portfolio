[comment]: <> (
  test machine: csel-apollo
  date: 03/05/21
  name: Kiet Ho, Austin Glynn, Frank Back
  x500: hoxxx433, glynn047, backx039
  )

# Purpose
This project involves a C program used to translate Virtual Addresses to Physical Addresses using given page table simulating OS' translation process. The project also implements a TLB system using FIFO and LRU.


# What it does
The program takes in a text file of virtual addresses, extracts the most significant bits from the address to index into given page tables. The translated addresses are stored in a TLB in a FIFO or LRU fashion.

The main functionalities are:
* Translation
* TLB with FIFO
* LRU caching implemented for extra credits

## How to Compile
Download repository, use make command to build in command line.

Compiling:
```bash
make
```

Cleanup:
```bash
make clean
```

## Usage
To run in command line:
```bash
./vmanager
```
Run with least recently used flag:
```bash
./vmanager -lru
```

## Contributions
Program was done individually to be compiled as a team. Contribution are split up as follows:
* Kiet Ho: Implemented main, aux functionalities and compile project
* Frank Back: Implemented main and auxiliary functionalities
* Austin Glynn: Implemented main and auxiliary functionalities

## Known bugs
No bugs were detected.

## Test cases
0x72ae2247 manual input:
```bash
$ 0x72728247
```

## License
[MIT](https://choosealicense.com/licenses/mit/)
