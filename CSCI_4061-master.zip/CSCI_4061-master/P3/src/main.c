//main.c program to translate the virtual addresses from the virtual.txt
//into the physical frame address. Project 3 - CSci 4061

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "vmemory.h"

#define INPUT_FILE "../bin/virtual.txt"
#define MAXCHAR 1000
#define BUFFER_SIZE 100
#define BIT_COUNT 100

int main(int argc, char* argv[]){
	if (argc > 2) {
		printf("Too many arguments, enter up to one argument\n");
		exit(-1);
	}
	FILE *fp;
	char *str;
	unsigned int addr_int;
	int policy = (argc == 2) ? 1:0;
	initialize_vmanager(policy);

	fp = fopen(INPUT_FILE, "r");
	int count = 0;
	if (fp == NULL){
    printf("Could not open file %s",INPUT_FILE);
    return 1;
  }
	print_tlb();
  while (fgets(str, MAXCHAR, fp) != NULL){
		sscanf(str, "%x", &addr_int);
		// printf("Virtual address: %s", str);
		translate_virtual_address(addr_int);
	}
	print_tlb();
	printf("The hit rate of the cache is: %f\n", get_hit_ratio());
  fclose(fp);
	//Free the page table
	free_resources();
	return 0;
}
