//Implement the API modeling the translation of virtual page address to a
//physical frame address. We assume a 32 bit virtual memory and physical memory.
//Access to the page table is only via the CR3 register.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "vmemory.h"

#define OUT_TLB "../bin/tlb_out.txt"

bool FIFO_policy = true;
int **cr3;
struct TLB tlb;

struct TLB {
  int queue[8][2];
  int count;
  int total_calls;
  int hit;
};

static int get_bit(int addr, int start_bit, int length){
  // Get length bit from start_bit
  unsigned mask;
  mask = ((1 << length) -1) << start_bit;
  unsigned int result = (addr & mask)>>start_bit;
  return result;
}

void remove_queue(int index){
  // Remove item from queue at index
  if (tlb.count<0){
    printf("Queue is empty");
    return;
  }
  // printf("Removing at index: %d\n", index);
  // Shift elements left 1
  for (int i =index; i<tlb.count-1; i++){
    tlb.queue[i][0] = tlb.queue[i+1][0];
    tlb.queue[i][1] = tlb.queue[i+1][1];
  }
  tlb.count -= 1;
  return;
}

void enqueue(int v_addr, int p_addr){
  // Add items to queue at end, push out index 0
  if (tlb.count>=8){
    // printf("Queue full, pushing new item\n");
    remove_queue(0);
  }
  tlb.queue[tlb.count][0] = v_addr;
  tlb.queue[tlb.count][1] = p_addr;
  tlb.count += 1;
}

// The implementation of get_vpage_cr3 is provided in
// an object file, so no need to re-implement it
void initialize_vmanager(int policy)
{
	// Set LRU policy when passsed as a parameter
	if (policy){
		FIFO_policy = false;
  }
	cr3 = get_vpage_cr3();
  tlb.count = 0;
  tlb.total_calls = 0;
  tlb.hit = 0;

	// printf("cr3: %p\n", cr3);
}

//
// The implementation of following functions is required
//
int translate_virtual_address(unsigned int v_addr)
{
  int MSB_20 = get_bit(v_addr, 12 ,20);
  int offset = get_bit(v_addr, 0 ,12);
  int frame = get_tlb_entry(MSB_20);
  // Address not in table, do translation
  if (frame == -1){
    int MSB_10 = get_bit(v_addr, 22 ,10);
    int second_lvl = get_bit(v_addr, 12 ,10);
    int *scnd_tbl = cr3[MSB_10];
    frame = scnd_tbl[second_lvl];
    populate_tlb(MSB_20, frame);
  }
  print_physical_address(frame, offset);
	return -1;
}

void print_physical_address(int frame, int offset)
{
  if (frame == -1){
    printf("-1");
    return;
  }
	int vir_addr = (frame*4096)+offset;
  // printf("Physical address: ", );
  printf("0x%08x\n", vir_addr);
	return;
}

int get_tlb_entry(int n){
  int result;
  tlb.total_calls += 1;
	for (int i = 0; i < tlb.count; i++){
    // Address is in table
    if( tlb.queue[i][0] == n){
      // printf("Address found in table at index: %d\n", i);
      result = tlb.queue[i][1];
      tlb.hit += 1;
      if (!FIFO_policy){
        // Make most recently hit last
        remove_queue(i);
        enqueue(n, result);
      }
      return result;
    }
  }
  // printf("Address not in table\n");
	return -1;
}

void populate_tlb(int v_addr, int p_addr){
  enqueue(v_addr, p_addr);
	return;
}

float get_hit_ratio(){
  // printf("Hit: %d\n", tlb.hit);
  // printf("Calls: %d\n", tlb.total_calls);
  if (tlb.total_calls){
    return (float) tlb.hit/tlb.total_calls;
  }
	return 0.0;
}

//Write to the file in OUT_TLB
void print_tlb(){
  FILE *fp;
  fp = fopen(OUT_TLB, "ab");
	for (int i = 0; i < 8; i++){
    if (tlb.queue[i][0]){
      fprintf(fp, "0x%05x 0x%05x\n", tlb.queue[i][0], tlb.queue[i][1]);
    } else {
      fprintf(fp, "-1 -1\n");
    }
  }
  fprintf(fp, "\n");
  fclose(fp);
	return;
}
