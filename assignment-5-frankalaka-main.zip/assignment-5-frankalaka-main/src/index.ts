/* CSCI 5619 Assignment 5, Fall 2020
 * Author: Evan Suma Rosenberg
 * License: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
 */ 

import { Engine } from "@babylonjs/core/Engines/engine";
import { Scene } from "@babylonjs/core/scene";
import { Vector3, Color3, Space } from "@babylonjs/core/Maths/math";
import { UniversalCamera } from "@babylonjs/core/Cameras/universalCamera";
import { WebXRControllerComponent } from "@babylonjs/core/XR/motionController/webXRControllerComponent";
import { WebXRInputSource } from "@babylonjs/core/XR/webXRInputSource";
import { WebXRCamera } from "@babylonjs/core/XR/webXRCamera";
import { WebXRManagedOutputCanvasOptions } from "@babylonjs/core/XR/webXRManagedOutputCanvas";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { AbstractMesh } from "@babylonjs/core/Meshes/abstractMesh";
import { MeshBuilder } from  "@babylonjs/core/Meshes/meshBuilder";
import { InstancedMesh } from "@babylonjs/core/Meshes/instancedMesh";
import { StandardMaterial} from "@babylonjs/core/Materials/standardMaterial";
import { LinesMesh } from "@babylonjs/core/Meshes/linesMesh";
import { Logger } from "@babylonjs/core/Misc/logger";
import { Ray } from "@babylonjs/core/Culling/ray";
import { Mesh } from "@babylonjs/core/Meshes/mesh";
import { TransformNode } from "@babylonjs/core/Meshes/transformNode";
import { AssetsManager } from "@babylonjs/core/Misc";
import { SceneLoader } from "@babylonjs/core/Loading/sceneLoader";
import { PointerEventTypes, PointerInfo } from "@babylonjs/core/Events/pointerEvents";

// Side effects
import "@babylonjs/core/Helpers/sceneHelpers";

// Import debug layer
import "@babylonjs/inspector";


/******* Start of the Game class ******/ 
class Game 
{ 
    private canvas: HTMLCanvasElement;
    private engine: Engine;
    private scene: Scene;

    private xrCamera: WebXRCamera | null; 
    private leftController: WebXRInputSource | null;
    private rightController: WebXRInputSource | null;

    private selectedObject: AbstractMesh | null;
    private selectionTransform: TransformNode | null;

    private visualTransform: TransformNode | null;

    private laserPointer: LinesMesh | null;
    private groundCopy: InstancedMesh | null;

    private regMaterial: StandardMaterial;
    private selectMaterial: StandardMaterial;

    private meshList: Mesh[];
    private instancedMeshList: InstancedMesh[];

    constructor()
    {
        // Get the canvas element 
        this.canvas = document.getElementById("renderCanvas") as HTMLCanvasElement;

        // Generate the BABYLON 3D engine
        this.engine = new Engine(this.canvas, true, { stencil: true }); 

        // Creates a basic Babylon Scene object
        this.scene = new Scene(this.engine);   

        // Initialize XR member variables to null
        this.xrCamera = null;
        this.leftController = null;
        this.rightController = null;

        this.selectedObject = null;
        this.selectionTransform = null;

        this.visualTransform = null;
        
        this.laserPointer = null;
        this.groundCopy = null;
        
        this.meshList = [];
        this.instancedMeshList = [];

        this.regMaterial = new StandardMaterial("blueMaterial", this.scene);
        this.regMaterial.diffuseColor = new Color3(0, 0, 1);

        this.selectMaterial = new StandardMaterial("redMaterial", this.scene);
        this.selectMaterial.diffuseColor = new Color3(1, 0, 0);
    }

    start() : void 
    {
        // Create the scene and then execute this function afterwards
        this.createScene().then(() => {

            // Register a render loop to repeatedly render the scene
            this.engine.runRenderLoop(() => { 
                this.update();
                this.scene.render();
            });

            // Watch for browser/canvas resize events
            window.addEventListener("resize", () => { 
                this.engine.resize();
            });
        });
    }

    private async createScene() 
    {
        // This creates and positions a first-person camera (non-mesh)
        var camera = new UniversalCamera("camera1", new Vector3(0, 1.6, 0), this.scene);
        camera.fov = 90 * Math.PI / 180;
        camera.minZ = .1;
        camera.maxZ = 100;

        // This attaches the camera to the canvas
        camera.attachControl(this.canvas, true);

        // Creates the XR experience helper
        const xrHelper = await this.scene.createDefaultXRExperienceAsync({});

        // Disable teleportation and the laser pointer
        xrHelper.teleportation.dispose();
        xrHelper.pointerSelection.dispose();

        // Assign the xrCamera to a member variable
        this.xrCamera = xrHelper.baseExperience.camera;

        // Assigns the controllers
        xrHelper.input.onControllerAddedObservable.add((inputSource) =>
        {
            if(inputSource.uniqueId.endsWith("left")) 
            {
                this.leftController = inputSource;
            }
            else 
            {
                this.rightController = inputSource;
            }  
        });

        // Creates a default skybox
        const environment = this.scene.createDefaultEnvironment({
            createGround: true,
            groundSize: 50,
            skyboxSize: 50,
            skyboxColor: new Color3(0, 0, 0)
        });

        // There is a bug in Babylon 4.1 that fails to enable the highlight layer on the Oculus Quest. 
        // This workaround fixes the problem.
        var canvasOptions = WebXRManagedOutputCanvasOptions.GetDefaults();
        canvasOptions.canvasOptions!.stencil = true;

        // Fix Highlight Mesh
        this.scene.setRenderingAutoClearDepthStencil(1, false, true, false);

        // Make sure the environment and skybox is not pickable!
        environment!.ground!.isPickable = false;
        environment!.skybox!.isPickable = false;

        // This creates a light, aiming 0,1,0 - to the sky (non-mesh)
        var light = new HemisphericLight("light", new Vector3(0, 1, 0), this.scene);

        // Default intensity is 1. Let's dim the light a small amount
        light.intensity = 0.7;

//------------------------------------------------------------------------------------------------------------
        
        // Create points for the laser pointer
        var laserPoints = [];
        laserPoints.push(new Vector3(0, 0, 0));
        laserPoints.push(new Vector3(0, 0, 10));

        // Create a laser pointer and make sure it is not pickable
        this.laserPointer = MeshBuilder.CreateLines("laserPointer", {points: laserPoints}, this.scene);
        this.laserPointer.color = Color3.Blue();
        this.laserPointer.alpha = .5;
        this.laserPointer.visibility = 0;
        this.laserPointer.isPickable = false;

//------------------------------------------------------------------------------------------------------------

        var ground = MeshBuilder.CreateBox("ground", {width: 8, height: 0.05, depth: 8}, this.scene);
        ground.position = new Vector3(0,-.026,0.2);
        ground.isPickable = false;

        this.groundCopy = new InstancedMesh("groundCopy", ground);
        this.groundCopy.position = new Vector3(ground.position.x/10, ground.position.y/10+0.1, ground.position.z/10);
        this.groundCopy.scaling = new Vector3(.05, .05, .05);
        this.groundCopy.isPickable = false;
        
//------------------------------------------------------------------------------------------------------------

        // This transform will be used to attach objects to the laser pointer
        this.selectionTransform = new TransformNode("selectionTransform", this.scene);
        this.visualTransform = new TransformNode("visualTransform", this.scene);
        this.selectionTransform.parent = this.laserPointer;
        this.visualTransform.parent = this.groundCopy;

        // Attach the laser pointer to the right controller when it is connected
        xrHelper.input.onControllerAddedObservable.add((inputSource) => {
            if(inputSource.uniqueId.endsWith("right"))
            {
                this.rightController = inputSource;
                this.laserPointer!.parent = this.rightController.pointer;
                this.laserPointer!.visibility = 1;
            }
            else 
            {
                this.leftController = inputSource;
                this.groundCopy!.parent = this.leftController.pointer;
            }  
        });

        // Don't forget to deparent the laser pointer or it will be destroyed!
        xrHelper.input.onControllerRemovedObservable.add((inputSource) => {

            if(inputSource.uniqueId.endsWith("right")) 
            {
                this.laserPointer!.parent = null;
                this.laserPointer!.visibility = 0;
            }
            else
            {
                this.groundCopy!.parent = null;
            }
        });



//------------------------------------------------------------------------------------------------------------
     
        /// Loading multiple assets
        var assetsManager = new AssetsManager(this.scene);

        var worldTask1 = assetsManager.addMeshTask("World Task 1", "", "assets/", "BEDROOM_FURNITURE.obj");
        worldTask1.onSuccess = (task) => {
            worldTask1.loadedMeshes.forEach((mesh) => {
                mesh.scaling = new Vector3(.5, .5, .5);
                mesh.isPickable = false;
            });
        }

        var worldTask2 = assetsManager.addMeshTask("World Task 2", "", "assets/", "BEDROOM_FURNITURE.obj");
        worldTask2.onSuccess = (task) => {
            worldTask2.loadedMeshes.forEach((mesh) => {
                mesh.scaling = new Vector3(.025, .025, .025);
                mesh.position = new Vector3(0,0.1,0)
                mesh.isPickable = false;
                mesh.setParent(this.groundCopy);
            });
        }

        assetsManager.load();
        // Our built-in 'sphere' shape.
        var wall1 = MeshBuilder.CreateBox("wall1", {width: 8, height: 3, depth: .1}, this.scene);
        wall1.position = new Vector3(0,1.5,-3.7);
        wall1.isPickable = false;
        var wall2 = MeshBuilder.CreateBox("wall2", {width: .1, height: 3, depth: 8}, this.scene);
        wall2.position = new Vector3(4,1.5,0.2);
        wall2.isPickable = false;
        var wall3 = MeshBuilder.CreateBox("wall3", {width: 8, height: 3, depth: .1}, this.scene);
        wall3.position = new Vector3(0,1.5,4.1);
        wall3.isPickable = false;
        var wall4 = MeshBuilder.CreateBox("wall4", {width: .1, height: 3, depth: 8}, this.scene);
        wall4.position = new Vector3(-4,1.5,0.2);
        wall4.isPickable = false;


        var sphere1 = MeshBuilder.CreateSphere("xsphere1", {diameter: .5, segments: 32}, this.scene);
        sphere1.position = new Vector3(2.5,2,2);
        this.meshList.push(sphere1);
        var sphere2 = MeshBuilder.CreateSphere("xsphere2", {diameter: .5, segments: 32}, this.scene);
        sphere2.position = new Vector3(1.5,2,2);
        this.meshList.push(sphere2);
        var sphere3 = MeshBuilder.CreateSphere("xsphere3", {diameter: .5, segments: 32}, this.scene);
        sphere3.position = new Vector3(.5,2,2);
        this.meshList.push(sphere3);
        var sphere4 = MeshBuilder.CreateSphere("xsphere4", {diameter: .5, segments: 32}, this.scene);
        sphere4.position = new Vector3(-.5,2,2);
        this.meshList.push(sphere4);
        var sphere5 = MeshBuilder.CreateSphere("xsphere5", {diameter: .5, segments: 32}, this.scene);
        sphere5.position = new Vector3(-1.5,2,2);
        this.meshList.push(sphere5);
        var sphere6 = MeshBuilder.CreateSphere("xsphere6", {diameter: .5, segments: 32}, this.scene);
        sphere6.position = new Vector3(-2.5,2,2);
        this.meshList.push(sphere6);

        // Use an instanced mesh to efficiently create a copy of an object
        // var sphereCopy = new InstancedMesh("sphereCopy", sphere);
        // sphereCopy.position = new Vector3(1, 1.6, 2)
        // sphereCopy.scaling = new Vector3(1, 2, 1);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere1Copy = new InstancedMesh("sphereCopy1", sphere1);
        sphere1Copy.position = new Vector3(sphere1.position.x/20 , sphere1.position.y/20+0.1, sphere1.position.z/20);
        sphere1Copy.scaling = new Vector3(.05, .05, .05);
        sphere1Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere1Copy);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere2Copy = new InstancedMesh("sphereCopy2", sphere2);
        sphere2Copy.position = new Vector3(sphere2.position.x/20 , sphere2.position.y/20+0.1, sphere2.position.z/20);
        sphere2Copy.scaling = new Vector3(.05, .05, .05);
        sphere2Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere2Copy);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere3Copy = new InstancedMesh("sphereCopy3", sphere3);
        sphere3Copy.position = new Vector3(sphere3.position.x/20 , sphere3.position.y/20+0.1, sphere3.position.z/20);
        sphere3Copy.scaling = new Vector3(.05, .05, .05);
        sphere3Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere3Copy);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere4Copy = new InstancedMesh("sphereCopy4", sphere4);
        sphere4Copy.position = new Vector3(sphere4.position.x/20 , sphere4.position.y/20+0.1, sphere4.position.z/20);
        sphere4Copy.scaling = new Vector3(.05, .05, .05);
        sphere4Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere4Copy);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere5Copy = new InstancedMesh("sphereCopy5", sphere5);
        sphere5Copy.position = new Vector3(sphere5.position.x/20 , sphere5.position.y/20+0.1, sphere5.position.z/20);
        sphere5Copy.scaling = new Vector3(.05, .05, .05);
        sphere5Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere5Copy);

        // Use an instanced mesh to efficiently create a copy of an object
        var sphere6Copy = new InstancedMesh("sphereCopy6", sphere6);
        sphere6Copy.position = new Vector3(sphere6.position.x/20 , sphere6.position.y/20+0.1, sphere6.position.z/20);
        sphere6Copy.scaling = new Vector3(.05, .05, .05);
        sphere6Copy.setParent(this.groundCopy);
        this.instancedMeshList.push(sphere6Copy);

        sphere1.material = this.regMaterial;
        sphere2.material = this.regMaterial;
        sphere3.material = this.regMaterial;
        sphere4.material = this.regMaterial;
        sphere5.material = this.regMaterial;
        sphere6.material = this.regMaterial;

        // Show the debug layer
        this.scene.debugLayer.show();
    }

    // The main update loop will be executed once per frame before the scene is rendered
    private update() : void
    {
        // Polling for controller input
        this.processControllerInput();
    }

    private processControllerInput()
    {
        this.onRightTrigger(this.rightController?.motionController?.getComponent("xr-standard-trigger"));
        this.onRightThumbstick(this.rightController?.motionController?.getComponent("xr-standard-thumbstick"));
    }

    private onRightTrigger(component?: WebXRControllerComponent)
    {  
        if(component?.changes.pressed)
        {
            if(component?.pressed)
            {
                this.laserPointer!.color = Color3.Green();

                var ray = new Ray(this.rightController!.pointer.position, this.rightController!.pointer.forward, 10);
                var pickInfo = this.scene.pickWithRay(ray);

                // Deselect the currently selected object 
                if(this.selectedObject)
                {
                    if(this.selectedObject instanceof Mesh) {
                        this.selectedObject!.material = this.regMaterial;
                        for(var i = 0; i < this.instancedMeshList.length; i++){
                            this.instancedMeshList[i].position = new Vector3(this.meshList[i].position.x , this.meshList[i].position.y, this.meshList[i].position.z-.4)
                        };
                    }
                    else {
                        (<InstancedMesh>this.selectedObject!).sourceMesh.material = this.regMaterial;
                        (<InstancedMesh>this.selectedObject!).sourceMesh.position = new Vector3((this.selectedObject.position.x), (this.selectedObject.position.y-0.1), (this.selectedObject.position.z+.4));
                    }
                    this.selectedObject = null;
                }

                // If an object was hit, select it
                if(pickInfo?.hit)
                {
                    this.selectedObject = pickInfo!.pickedMesh;
                    // this.selectedObject!.enableEdgesRendering(); 
                    if(this.selectedObject instanceof Mesh) {
                        this.selectedObject!.material = this.selectMaterial;
                    }
                    else {
                        (<InstancedMesh>this.selectedObject!).sourceMesh.material = this.selectMaterial;
                    }
                    // Parent the object to the transform on the laser pointer
                    this.selectionTransform!.position = new Vector3(0, 0, pickInfo.distance);
                    this.selectedObject!.setParent(this.selectionTransform!);
                }
            }
            else
            {
                // Reset the laser pointer color
                this.laserPointer!.color = Color3.Blue();

                // Release the object from the laser pointer
                if(this.selectedObject)
                {
                    if(this.selectedObject instanceof Mesh) {
                        this.selectedObject!.material = this.regMaterial;
                        this.selectedObject!.setParent(null);
                    }
                    else {
                        (<InstancedMesh>this.selectedObject!).sourceMesh.material = this.regMaterial;
                        this.selectedObject.setParent(this.groundCopy!);
                    }
                }  
            }
        }
    }

    private onRightThumbstick(component?: WebXRControllerComponent)
    {
        // If we have an object that is currently attached to the laser pointer
        if(component?.changes.axes && this.selectedObject && this.selectedObject.parent)
        {
            // Use delta time to calculate the proper speed
            var moveDistance = -component.axes.y * (this.engine.getDeltaTime() / 1000) * 3;

            // Translate the object along the depth ray in world space
            this.selectedObject.translate(this.laserPointer!.forward, moveDistance, Space.WORLD);
        }
    }


    

}
/******* End of the Game class ******/   

// start the game
var game = new Game();
game.start();