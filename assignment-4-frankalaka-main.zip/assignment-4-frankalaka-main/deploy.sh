#!/bin/sh

USER="backx039"
MACHINE="apollo.cselabs.umn.edu"
DIRECTORY=".www/Assignment-4/"

rm -rf dist/assets
cp -r assets dist/assets
rsync -avr --delete --chmod=D701,F644 dist/ "$USER"@"$MACHINE":"$DIRECTORY"
