/* CSCI 5619 Assignment 6, Fall 2020
 * Author: Evan Suma Rosenberg
 * License: Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International
 */ 

import { Engine } from "@babylonjs/core/Engines/engine";
import { Scene } from "@babylonjs/core/scene";
import { Vector3, Color3, Color4, Space } from "@babylonjs/core/Maths/math";
import { UniversalCamera } from "@babylonjs/core/Cameras/universalCamera";
import { WebXRControllerComponent } from "@babylonjs/core/XR/motionController/webXRControllerComponent";
import { WebXRInputSource } from "@babylonjs/core/XR/webXRInputSource";
import { WebXRCamera } from "@babylonjs/core/XR/webXRCamera";
import { WebXRSessionManager } from "@babylonjs/core/XR/webXRSessionManager";
import { PointLight } from "@babylonjs/core/Lights/pointLight";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { DirectionalLight } from "@babylonjs/core/Lights/directionalLight";
import { ShadowGenerator } from "@babylonjs/core/Lights/Shadows/shadowGenerator";
import { HighlightLayer } from "@babylonjs/core/Layers/highlightLayer"
import { Logger } from "@babylonjs/core/Misc/logger";
import { AbstractMesh } from "@babylonjs/core/Meshes/abstractMesh";
import { Mesh } from "@babylonjs/core/Meshes/mesh";
import { MeshBuilder } from  "@babylonjs/core/Meshes/meshBuilder";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { LinesMesh } from "@babylonjs/core/Meshes/linesMesh";
import { Ray } from "@babylonjs/core/Culling/ray";
import { Axis } from "@babylonjs/core/Maths/math.axis";
import { Quaternion } from "@babylonjs/core/Maths/math.vector";
import { AssetsManager } from "@babylonjs/core/Misc";
import { Animation } from "@babylonjs/core/Animations/animation";

// Side effects
import "@babylonjs/core/Helpers/sceneHelpers";
import "@babylonjs/inspector";
import { Camera, SphereBuilder } from "@babylonjs/core";
import { DirectionalLightPropertyGridComponent } from "@babylonjs/inspector/components/actionTabs/tabs/propertyGrids/lights/directionalLightPropertyGridComponent";


enum LocomotionMode 
{
    viewDirected,
    handDirected,
    teleportation
}

class Game 
{ 
    private canvas: HTMLCanvasElement;
    private engine: Engine;
    private scene: Scene;

    private camera: UniversalCamera | null;
    private xrCamera: WebXRCamera | null; 
    private xrSessionManager: WebXRSessionManager | null;
    private leftController: WebXRInputSource | null;
    private rightController: WebXRInputSource | null;

    private target: Mesh | null;
    private arrowLocation: Mesh | null;
    private gameCounter: number;
    private keys1: Vector3[];
    private fly: boolean;
    private snapTurn: boolean;

    private locomotionMode: LocomotionMode;
    private laserPointer: LinesMesh | null;
    private groundMeshes: Array<AbstractMesh>;
    private teleportPoint: Vector3 | null;

    constructor()
    {
        // Get the canvas element 
        this.canvas = document.getElementById("renderCanvas") as HTMLCanvasElement;

        // Generate the BABYLON 3D engine
        this.engine = new Engine(this.canvas, true, {stencil: true}); 

        // Creates a basic Babylon Scene object
        this.scene = new Scene(this.engine);

        this.camera = null;
        this.xrCamera = null;
        this.xrSessionManager = null;
        this.leftController = null;
        this.rightController = null;

        this.target = null;
        this.arrowLocation = null;
        this.gameCounter = 0;
        this.keys1 = [];
        this.fly = false;
        this.snapTurn = true;
        
        this.locomotionMode = LocomotionMode.viewDirected;
        this.laserPointer = null;
        this.groundMeshes = [];
        this.teleportPoint = null;  
    }

    start() : void 
    {
        // Create the scene and then execute this function afterwards
        this.createScene().then(() => {

            // Register a render loop to repeatedly render the scene
            this.engine.runRenderLoop(() => { 
                this.update();
                this.scene.render();
            });

            // Watch for browser/canvas resize events
            window.addEventListener("resize", () => { 
                this.engine.resize();
            });
        });
    }

    private async createScene() 
    {
        // This creates and positions a first-person camera (non-mesh)
        this.camera = new UniversalCamera("camera1", new Vector3(2, 1.6, -45), this.scene);
        this.camera.fov = 90 * Math.PI / 180;
        this.camera.minZ = .1;
        this.camera.maxZ = 200;

        // This attaches the camera to the canvas
        this.camera.attachControl(this.canvas, true);

        this.scene.ambientColor
        // This creates a light, aiming 0,1,0 - to the sky (non-mesh)
        var light1 = new DirectionalLight("light", new Vector3(0, -1, 0), this.scene);

        // Default intensity is 1. Let's dim the light a small amount
        light1.intensity = 2.0;
        light1.diffuse = new Color3(1, 1, 1);

        // Creates a default skybox
        const environment = this.scene.createDefaultEnvironment({
            createGround: true,
            groundSize: 100,
            skyboxSize: 150,
            skyboxColor: new Color3(0, 0, 0)
        });

        // Make sure the skybox is not pickable!
        environment!.skybox!.isPickable = false;

        // The ground should be pickable for teleportation
        this.groundMeshes.push(environment!.ground!);

        // Creates the XR experience helper
        const xrHelper = await this.scene.createDefaultXRExperienceAsync({});

        // Assigns the web XR camera and session manager to member variables
        this.xrCamera = xrHelper.baseExperience.camera;
        this.xrSessionManager = xrHelper.baseExperience.sessionManager;

        // Remove default teleportation and pointer selection
        xrHelper.teleportation.dispose();
        xrHelper.pointerSelection.dispose();

        // Create points for the laser pointer
        var laserPoints = [];
        laserPoints.push(new Vector3(0, 0, 0));
        laserPoints.push(new Vector3(0, 0, 1));

        // Create a laser pointer and make sure it is not pickable
        this.laserPointer = MeshBuilder.CreateLines("laserPointer", {points: laserPoints}, this.scene);
        this.laserPointer.color = Color3.White();
        this.laserPointer.alpha = .5;
        this.laserPointer.visibility = 0;
        this.laserPointer.isPickable = false;

        // Attach the laser pointer to the right controller when it is connected
        xrHelper.input.onControllerAddedObservable.add((inputSource) => {
            if(inputSource.uniqueId.endsWith("right"))
            {
                this.rightController = inputSource;
                this.laserPointer!.parent = this.rightController.pointer;
            }
            else 
            {
                this.leftController = inputSource;
            }  
        });

        // Don't forget to deparent the laser pointer or it will be destroyed!
        xrHelper.input.onControllerRemovedObservable.add((inputSource) => {

            if(inputSource.uniqueId.endsWith("right")) 
            {
                this.laserPointer!.parent = null;
                this.laserPointer!.visibility = 0;
            }
        });

        var assetsManager = new AssetsManager(this.scene);

        var worldTask1 = assetsManager.addMeshTask("Maze", "", "assets/", "maze.obj");
        worldTask1.onSuccess = (task) => {
            worldTask1.loadedMeshes.forEach((mesh) => {
                mesh.scaling = new Vector3(.5, .5, .5);
                mesh.position = new Vector3(0,-0.1,0)
                mesh.isPickable = false;
                mesh.enableEdgesRendering(); 
                mesh.edgesWidth = 4.0;
                mesh.edgesColor = new Color4(0, 0, 1, 1);
            });
        }

        assetsManager.load();

        var regMaterial = new StandardMaterial("blueMaterial", this.scene);
        regMaterial.diffuseColor = new Color3(0, 0, 0);
        regMaterial.ambientTexture = regMaterial.diffuseTexture; 
        var ground = MeshBuilder.CreateBox("ground", {width: 150, height: 0.05, depth: 150}, this.scene);
        ground.position = new Vector3(0,0,0);
        ground.isPickable = false;
        ground.material = regMaterial;
        this.groundMeshes.push(ground);

        this.target = MeshBuilder.CreateSphere("target", {diameter: 2}, this.scene);
        this.target.position = new Vector3(1.75, 1.6, -40);

        // Animation part 1
        var animationBox1 = new Animation("myAnimation1", "position", 30, Animation.ANIMATIONTYPE_FLOAT, Animation.ANIMATIONLOOPMODE_CYCLE);

        // An array with all animation keys
        this.keys1.push(new Vector3(1.75, 1.6, -40));
        this.keys1.push(new Vector3(1.75, 1.6, 3.6));
        this.keys1.push(new Vector3(25.75, 1.6, 3.6));
        this.keys1.push(new Vector3(25.75, 1.6, -2.25));
        this.keys1.push(new Vector3(38, 1.6, -2.25));
        this.keys1.push(new Vector3(38, 1.6, -14));
        this.keys1.push(new Vector3(56, 1.6, -14));
        this.keys1.push(new Vector3(56, 1.6, -20));
        this.keys1.push(new Vector3(62.25, 1.6, -20));
        this.keys1.push(new Vector3(62.25, 1.6, 21.5));
        this.keys1.push(new Vector3(26, 1.6, 21.5));
        this.keys1.push(new Vector3(26, 1.6, 15.25));
        this.keys1.push(new Vector3(30, 1.6, 15.25));
        this.keys1.push(new Vector3(38, 1.6, 15.25));
        this.keys1.push(new Vector3(38, 1.6, 3.5));
        this.keys1.push(new Vector3(31.5, 1.6, 3.5));
        this.keys1.push(new Vector3(31.5, 1.6, 9.5));
        this.keys1.push(new Vector3(14, 1.6, 9.5));
        this.keys1.push(new Vector3(14, 1.6, 15.5));
        this.keys1.push(new Vector3(20, 1.6, 15.5));
        this.keys1.push(new Vector3(20, 1.6, 27));
        this.keys1.push(new Vector3(14, 1.6, 27));
        this.keys1.push(new Vector3(14, 1.6, 45));
        this.keys1.push(new Vector3(-53, 1.6, 45));
        this.keys1.push(new Vector3(-53, 1.6, -14));
        this.keys1.push(new Vector3(-46.8, 1.6, -14));
        this.keys1.push(new Vector3(-46.8, 1.6, -20));
        this.keys1.push(new Vector3(-40, 1.6, -20));
        this.keys1.push(new Vector3(-40, 1.6, -37.5));
        this.keys1.push(new Vector3(-28, 1.6, -37.5));
        this.keys1.push(new Vector3(-28, 1.6, -25.5));
        this.keys1.push(new Vector3(-34.5, 1.6, -25.5));
        this.keys1.push(new Vector3(-34.5, 1.6, -25.5));

        this.arrowLocation = MeshBuilder.CreateCylinder("arrow", { diameterTop: 0, diameterBottom: 1.5, height: 1.5}, this.scene);
        this.arrowLocation.position = new Vector3(2,-1.6,0);
        this.arrowLocation.rotate(Axis.X, Math.PI/2, Space.WORLD);

        this.scene.debugLayer.show(); 
    }

    // The main update loop will be executed once per frame before the scene is rendered
    private update() : void
    {
        this.updateTarget();
        this.userTest();
        this.processControllerInput();
    }

    private updateTarget() : void 
    {
        var goalPosition = this.keys1[this.gameCounter];
        var goalDistance = Vector3.Distance(goalPosition,this.target!.position);
        var direction = goalPosition.subtract(this.target!.position).normalize();
        if(goalDistance < 1/30) {
            this.target!.position = goalPosition;
            this.gameCounter += 1;
        } else {
            this.target!.position.x = this.target!.position.x + direction.x/30;
            this.target!.position.y = this.target!.position.y + direction.y/30;
            this.target!.position.z = this.target!.position.z + direction.z/30;
        }
    }

    private userTest() : void
    {
        if(Vector3.Distance(this.camera!.position,this.target!.position) > 10 && Vector3.Distance(this.xrCamera!.position,this.target!.position) > 10){
            this.gameCounter = 0;
            this.target!.position = new Vector3(1.75, 1.6, -40);
            this.camera!.position = new Vector3(2, 1.6, -45);
            this.xrCamera!.position = new Vector3(2, 1.6, -45);
        }
    }

    // Process event handlers for controller input
    private processControllerInput()
    {
        this.onRightA(this.rightController?.motionController?.getComponent("a-button"));
        this.onRightB(this.rightController?.motionController?.getComponent("b-button"));
        this.onRightThumbstick(this.rightController?.motionController?.getComponent("xr-standard-thumbstick"));    
    }

    private onRightThumbstick(component?: WebXRControllerComponent)
    {   
        if(component?.axes.x == 0 && component?.axes.y == 0){
            this.snapTurn = true;
        }
        if(component?.changes.axes)
        {
            // View-directed steering
            if(this.locomotionMode == LocomotionMode.viewDirected)
            {   
                // Get the current camera direction
                var directionVector = this.xrCamera!.getDirection(Axis.Z);
                if(this.fly == false){
                    directionVector.y = 0;
                    directionVector.normalize();
                }

                // Use delta time to calculate the move distance based on speed of 3 m/sec
                var moveDistance = -component.axes.y * (this.engine.getDeltaTime() / 1000) * 3;

                // Translate the camera forward
                this.xrCamera!.position.addInPlace(directionVector.scale(moveDistance));

                var componentX = component.axes.x;
                if(this.snapTurn) {
                    if(componentX > .8) {
                        var cameraRotation = Quaternion.FromEulerAngles(0, Math.PI/2, 0);
                        this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        this.snapTurn = false;
                    }
                    else if(componentX < -.8) {
                        var cameraRotation = Quaternion.FromEulerAngles(0, -Math.PI/2, 0);
                        this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        this.snapTurn = false;
                    }
                }
            }
            else if(this.locomotionMode == LocomotionMode.handDirected)
            {
                // Get the current hand direction
                var directionVector = this.rightController!.pointer.forward;
                if(this.fly == false){
                    directionVector.y = 0;
                    directionVector.normalize();
                }

                // Use delta time to calculate the move distance based on speed of 3 m/sec
                var moveDistance = -component.axes.y * (this.engine.getDeltaTime() / 1000) * 3;

                // Translate the camera forward
                this.xrCamera!.position.addInPlace(directionVector.scale(moveDistance));

                var componentX = component.axes.x;
                if(this.snapTurn) {
                    if(componentX > .8) {
                        var cameraRotation = Quaternion.FromEulerAngles(0, Math.PI/2, 0);
                        this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        this.snapTurn = false;
                    }
                    else if(componentX < -.8) {
                        var cameraRotation = Quaternion.FromEulerAngles(0, -Math.PI/2, 0);
                        this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        this.snapTurn = false;
                    }
                }
            }
            // Teleportation
            else
            {
                // If the thumbstick is moved forward
                if(component.axes.y < -.75)
                {
                    // Create a new ray cast
                    var ray = new Ray(this.rightController!.pointer.position, this.rightController!.pointer.forward, 20);
                    var pickInfo = this.scene.pickWithRay(ray);

                    var directionVector = this.leftController!.pointer.forward;
                    directionVector.y = 0;
                    directionVector.normalize();

                    // If the ray cast intersected a ground mesh
                    if(pickInfo?.hit && this.groundMeshes.includes(pickInfo.pickedMesh!))
                    {
                        this.teleportPoint = pickInfo.pickedPoint;
                        this.arrowLocation!.position = this.teleportPoint!.clone();
                        this.arrowLocation!.position.y = 1.6;
                        this.arrowLocation!.rotation = new Vector3(0,0,0);
                        this.arrowLocation!.rotate(Axis.X, Math.PI/2, Space.WORLD);
                        if(directionVector.z > 0) {
                            this.arrowLocation!.rotate(Axis.Y, Math.atan(directionVector.x/directionVector.z), Space.WORLD);
                        }
                        else {
                            this.arrowLocation!.rotate(Axis.Y, Math.atan(directionVector.x/directionVector.z)+Math.PI, Space.WORLD);
                        }
                        
                        this.laserPointer!.scaling.z = pickInfo.distance;
                        this.laserPointer!.visibility = 1;
                    }
                    else
                    {
                        this.teleportPoint = null;
                        this.laserPointer!.visibility = 0;
                        this.arrowLocation!.position.y = -1.6;
                    }
                }
                // If thumbstick returns to the rest position
                else if(component.axes.y == 0)
                {
                    this.laserPointer!.visibility = 0;
                    this.arrowLocation!.position.y = -1.6;

                    // If we have a valid targer point, then teleport the user
                    if(this.teleportPoint)
                    {
                        this.xrCamera!.position.x = this.teleportPoint.x;
                        this.xrCamera!.position.y = this.teleportPoint.y + this.xrCamera!.realWorldHeight;
                        this.xrCamera!.position.z = this.teleportPoint.z;
                        var directionVector = this.leftController!.pointer.up;
                        directionVector.y = 0;
                        directionVector.normalize();
                        
                        if(directionVector.z > 0) {
                            var cameraRotation = Quaternion.FromEulerAngles(0, Math.atan(directionVector.x/directionVector.z), 0);
                            this.xrCamera!.rotation = new Vector3(0, 0, 0);
                            this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        }
                        else {
                            var cameraRotation = Quaternion.FromEulerAngles(0, Math.atan(directionVector.x/directionVector.z), 0);
                            this.xrCamera!.rotation = new Vector3(0, 0, 0);
                            this.xrCamera!.rotationQuaternion.multiplyInPlace(cameraRotation);
                        }
                        
                        this.teleportPoint = null;
                    }
                }
            }
        }
    }

    // Toggle for locomotion mode
    private onRightA(component?: WebXRControllerComponent)
    {  
        if(component?.changes.pressed?.current)
        {
            if(this.locomotionMode == LocomotionMode.teleportation)
            {
                this.locomotionMode = 0;
            }
            else
            {
                this.locomotionMode += 1;
            }
        }
    }

        // Toggle for locomotion mode
    private onRightB(component?: WebXRControllerComponent)
    {  
        if(component?.changes.pressed?.current)
        {
            this.fly = !this.fly;
        }
    }
}
/******* End of the Game class ******/   

// start the game
var game = new Game();
game.start();