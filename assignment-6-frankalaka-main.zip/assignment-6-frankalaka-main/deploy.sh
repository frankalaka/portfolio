#!/bin/sh

USER="backx039"
MACHINE="csel-kh4240-01.cselabs.umn.edu"
DIRECTORY=".www/Assignment-6/"

#uncomment these lines if you add assets to the project
#rm -rf dist/assets
#cp -r assets dist/assets
rsync -avr --delete --chmod=D701,F644 dist/ "$USER"@"$MACHINE":"$DIRECTORY"
